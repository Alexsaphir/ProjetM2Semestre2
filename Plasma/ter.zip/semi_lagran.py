import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
#bon

alpha = 1/2
Beta = 1
N = int(input("N = nombre de point en x"))
P = int(input("P = nombre de point en v"))
M = int(input("M = nombre d'intervalle en temps"))
T = float(input("T = temps final"))
dt = T / (M + 1)
h = 1./(N + 1)
X = np.linspace(0, 1, N + 2)
V = np.linspace(-8,8,P+2)
hv = abs(V[2]-V[1])

def u0(x,v):
    Y = (1 + alpha*np.cos(2*np.pi*x)) * np.exp(-((v - Beta)**2)/2)
    return Y
def u(x,v,t):
    y = u0(x * np.cos(t) - v * np.sin(t), x * np.sin(t) + v * np.cos(t))
    return y


def caracX(val,vec):
    ksi = 0
    ident = 0
    a = np.size(vec)
    if (0 <= val <= 1):
        for i in range(a-1):
            if(vec[i] <= val < vec[i+1]):
                ident = i
        ksi = val - vec[ident]
        ksi = ksi/h
    while (val < 0 ):
        val = val+1
        for i in range(a-1):
            if(vec[i] <= val < vec[i+1]):
                ident = i
        ksi = val - vec[ident]
        ksi = ksi/h
    while (val > 1) :
        val = val -1
        for i in range(a-1):
            if(vec[i] <= val < vec[i+1]):
                ident = i
        ksi = val - vec[ident]
        ksi = ksi/h
    return [ident,ksi]



U = np.zeros((N+2,P+2))
for i in range(N+2):
    for j in range(P+2):
        U[i,j] = u0(X[i],V[j])
Utemp = U

for k in range(M+1):
    #1er split
    for j in range(int((P+2)/2)):
        ksi1 = h-(V[j]*dt)
        Utemp[N+1,j] = ksi1*U[N+1,j] + (1-ksi1)*U[0,j]
        for i in range(N+1):
            ksi = X[i+1]- (X[i]-V[j]*dt)
            Utemp[i,j] = (1-ksi)* U[i,j] + ksi*U[i+1,j] 
    for j in range(int((P+2)/2),P+2):
        ksi2 = h-(V[j]*dt)
        Utemp[0,j] = (1-ksi1)*U[N+1,j] + ksi1*U[0,j]
        for i in range(1,N+2):
            ksi = (X[i]-V[j]*dt) - X[i-1]
            Utemp[i,j] = (1-ksi)* U[i,j] + ksi*U[i-1,j]            
            
    
    
    
    #2e split
    for i in range(N+2):
        ksi2 = hv - X[i]*dt 
        U[i,P+1] = ksi2*Utemp[i,P+1]
        for j in range(P+1):
            ksi = V[j+1] - (V[j]+X[i]*dt)
            ksi = ksi/hv
            U[i,j] = (1-ksi)*Utemp[i,j] + ksi*Utemp[i,j+1]








fig = plt.figure()
ax = fig.gca(projection='3d')
X, V = np.meshgrid(X, V)
Z = u(X,V,T)
surf = ax.plot_surface(X, V, Z, cmap='viridis',edgecolor='none')
plt.show()
fig = plt.figure()
ax = fig.gca(projection='3d')
surf1 = ax.plot_surface(X, V,np.transpose(U),cmap='viridis')
plt.title('solution approchée avec champ de vecteur (-v,x)')
plt.show()
            