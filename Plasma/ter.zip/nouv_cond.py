import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D


alpha = 0.5
Beta = 1
N = int(input("N = nombre de point en x"))
P = int(input("P = nombre de point en v"))
M = int(input("M = nombre d'intervalle en temps"))
T = float(input("T = temps final"))
dt = T / (M + 1)

X = np.linspace(-5, 5, N + 2)
V = np.linspace(-5,5,P+2)
h = abs(X[2]-X[1])
hv = abs(V[2]-V[1])

#def u0(x,v):
#    Y = (1 + alpha*np.cos(2*np.pi*x)) * np.exp(-((v - Beta)**2)/2)
#    return Y


def u0(x,v):
    Y = np.exp(-10*(x**2))*np.exp(-(v**2))
    return Y

def u(x,v,t):
    y = u0(x * np.cos(t) - v * np.sin(t), x * np.sin(t) + v * np.cos(t))
    return y


def caracX(val,vec):
    ksi = 0
    ident = 0
    a = np.size(vec)
    if (-5 <= val <= 5):
        for i in range(a-1):
            if(vec[i] <= val < vec[i+1]):
                ident = i
            ksi = val - vec[ident]
            ksi = ksi/h
    return [ident,ksi]

def caracV(val,vec):
    ksi = 0
    ident = 0
    a = np.size(vec)
    if (-5 <= val <= 5):
        for i in range(a-1):
            if(vec[i] <= val < vec[i+1]):
                ident = i
            ksi = val - vec[ident]
            ksi = ksi/hv
    return [ident,ksi]

U = np.zeros((N+2,P+2))
for i in range(N+2):
    for j in range(P+2):
        U[i,j] = u0(X[i],V[j])
Utemp = U


for k in range(M+1):
    
    #1er split
    for j in range(int((P+2)/2)):
        Utemp[N+1,j] = 0
        for i in range(N+1):
            [ident,ksi] = caracX(X[i]-V[j]*dt,X)
            Utemp[i,j] = ksi* U[ident+1,j] + (1-ksi)*U[ident,j] 
    
    for j in range(int((P+2)/2),P+2):
        Utemp[0,j] = 0
        for i in range(1,N+2):
            [ident,ksi] = caracX(X[i]-V[j]*dt,X)
            Utemp[i,j] = (1-ksi)* U[ident,j] + ksi*U[ident+1,j]
    
    #2e split
    for i in range(int((N+2)/2)):
        #[ident2,ksi2] = caracX(V[P+1]+X[i]*dt,V,P+1) 
        U[i,0] = 0
        for j in range(1,P+2):
            [ident,ksi] = caracV(V[j]+X[i]*dt,V)
            U[i,j] = ksi*Utemp[i,ident+1] + (1-ksi)*Utemp[i,ident]
    
    for i in range(int((N+2)/2),N+2):
        #[ident2,ksi2] = caracX(V[P+1]+X[i]*dt,V,P+1) 
        U[i,P+1] = 0
        for j in range(P+1):
            [ident,ksi] = caracV(V[j]+X[i]*dt,V)
            U[i,j] = ksi*Utemp[i,ident+1] + (1-ksi)*Utemp[i,ident]





fig = plt.figure()
ax = fig.gca(projection='3d')
X, V = np.meshgrid(X, V)
Z = u(X,V,T)

Err = np.amax(abs(Z-U))

surf = ax.plot_surface(X, V, Z, cmap='viridis',edgecolor='none')
plt.show()


fig = plt.figure()
ax = fig.gca(projection='3d')
surf1 = ax.plot_surface(X, V,np.transpose(U),cmap='viridis')
plt.title('solution approchée avec champ de vecteur (-v,x)')
texterr = 'Erreur = ' +str(Err)
ax.text(-4,4,0.8, texterr, color='red')
plt.show()
            