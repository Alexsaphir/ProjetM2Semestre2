import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
from matplotlib.animation import FuncAnimation

print('CFL <=> abs(v*dt/dx) + abs(x*dt/dy) <= 1')
N = int(input("N = nombre de point en x"))
P = int(input("P = nombre de point en v"))
M = int(input("M = nombre d'intervalle en temps"))
T = float(input("T = temps final"))
dt = T / (M + 1)

X = np.linspace(-5, 5, N + 2)
V = np.linspace(-5,5,P+2)
h = abs(X[2]-X[1])
hv = abs(V[2]-V[1])

def u0(x,v):
    Y = np.exp(-10*(x**2))*np.exp(-(v**2))
    return Y

def u(x,v,t):
    y = u0(x * np.cos(t) - v * np.sin(t), x * np.sin(t) + v * np.cos(t))
    return y

U2 = np.zeros((N+2,P+2))
for i in range(N+2):
    for j in range(P+2):
        U2[i,j] = u0(X[i],V[j])

U2temp = np.zeros((N+2,P+2))
U2temp = U2
for k in range(M+1):
    U2temp = U2
    for i in range(1,N+1):
        for j in range(1,P+2):
            U2[i,j] =  U2temp[i,j]-(dt/h)*(max(V[j],0)*(U2temp[i,j]-U2temp[i-1,j]) + min(V[j],0)*(U2temp[i+1,j]-U2temp[i,j]))-(dt/hv)*X[i]*(U2temp[i,j]-U2temp[i,j-1])
    for j in range(1,P+2):
        U2[N+1,j] = U2temp[N+1,j]-(dt/h)*(max(V[j],0)*(U2temp[N+1,j]-U2temp[N,j]) + min(V[j],0)*(U2temp[0,j]-U2temp[N+1,j]))-(dt/hv)*X[N+1]*(U2temp[N+1,j]-U2temp[N+1,j-1])
        U2[0,j] =  U2temp[0,j]-(dt/h)*(max(V[j],0)*(U2temp[0,j]-U2temp[N+1,j]) + min(V[j],0)*(U2temp[1,j]-U2temp[0,j]))-(dt/hv)*X[0]*(U2temp[0,j]-U2temp[0,j-1])
    for i in range(1,N+1):
        U2[i,0] =  U2temp[i,0]-(dt/h)*(min(V[0],0)*(U2temp[i+1,0]-U2temp[i,0]))-(dt/hv)*X[i]*(U2temp[i,0])
        


fig = plt.figure()
ax = fig.gca(projection='3d')
X, V = np.meshgrid(X, V)
Z = u(X,V,T)

surf = ax.plot_surface(X, V, Z, cmap='viridis',edgecolor='none')
plt.show()


fig = plt.figure()
ax = fig.gca(projection='3d')
surf1 = ax.plot_surface(X, V,np.transpose(U2),cmap='viridis')
plt.title('solution approchée avec champ de vecteur (-v,x)')

plt.show()















